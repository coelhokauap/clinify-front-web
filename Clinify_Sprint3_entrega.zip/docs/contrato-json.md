# Contrato de dados entre JavaScript e Python

## Fluxo

1. O Front Web registra interações e atividades no localStorage do navegador.
2. O botão **Salvar dados** reúne os registros do usuário atual.
3. O JavaScript usa JSON.stringify e baixa clinify_dados.json.
4. O usuário informa esse arquivo ao programa Python.
5. O Python valida todo o pacote antes de alterar dados/dados_alunos.json.
6. O Python adiciona registros novos e atualiza registros com o mesmo ID quando o conteúdo mudou.

A transferência é manual. Não existe API, servidor de aplicação ou banco de dados.

## Versão

O campo versao deve ser o número inteiro 1. Versões diferentes são rejeitadas.

## Estrutura obrigatória

| Caminho | Tipo | Regra |
| --- | --- | --- |
| versao | número inteiro | deve ser 1 |
| gerado_em | texto | data e hora ISO 8601 |
| usuario | objeto | obrigatório |
| usuario.id | texto | identificador estável, normalmente o e-mail da conta demonstrativa |
| usuario.nome | texto | obrigatório, até 120 caracteres |
| usuario.email | texto | pode ser vazio, até 160 caracteres |
| usuario.perfil | texto | estudante, professor ou administrador |
| interacoes | lista | pode estar vazia |
| atividades | lista | pode estar vazia |

Cada interação contém:

| Campo | Tipo | Regra |
| --- | --- | --- |
| id | texto | único para o evento |
| tipo | texto | por exemplo navegacao, clique ou formulario |
| acao | texto | nome compreensível da ação |
| pagina | texto | caminho da página |
| data | texto | data e hora ISO 8601 |

Cada atividade contém:

| Campo | Tipo | Regra |
| --- | --- | --- |
| id | texto | identificador usado para evitar duplicação |
| tipo | texto | estudo ou simulado |
| recurso | texto | caso ou especialidade relacionada |
| titulo | texto | título mostrado ao usuário |
| estado | texto | por exemplo concluida |
| concluida_em | texto | data e hora ISO 8601 |
| duracao_segundos | número | zero ou maior |
| pontuacao | número | entre 0 e 100 |
| detalhes | objeto | dados específicos da atividade |

## Identificadores e duplicação

O JavaScript usa um ID determinístico para um módulo de estudo e um ID próprio para cada tentativa concluída de simulação. Na importação, o Python procura o ID dentro do mesmo usuário:

- ID inexistente: adiciona o registro.
- Mesmo ID e mesmo conteúdo: não altera nem duplica.
- Mesmo ID e conteúdo diferente: atualiza o registro.

Usuários diferentes mantêm listas separadas. A identidade é determinada por usuario.id.

## Exemplo fictício válido

~~~json
{
  "versao": 1,
  "gerado_em": "2026-09-19T14:30:00.000Z",
  "usuario": {
    "id": "aluno.demo@clinify.com",
    "nome": "Aluno Demonstração",
    "email": "aluno.demo@clinify.com",
    "perfil": "estudante"
  },
  "interacoes": [
    {
      "id": "interacao-demo-001",
      "tipo": "navegacao",
      "acao": "Clinify | Simulação Clínica",
      "pagina": "/estudante/simulacao.html",
      "data": "2026-09-19T14:20:00.000Z"
    }
  ],
  "atividades": [
    {
      "id": "simulado-demo-cefaleia-001",
      "tipo": "simulado",
      "recurso": "cefaleia",
      "titulo": "Cefaleia intensa inédita",
      "estado": "concluida",
      "concluida_em": "2026-09-19T14:29:00.000Z",
      "duracao_segundos": 420,
      "pontuacao": 82,
      "detalhes": {
        "materia": "neurologia",
        "criterios": ["inicio", "intensidade", "sinais_de_alerta"]
      }
    }
  ]
}
~~~

## Tratamento de erros

Arquivos ausentes, JSON malformado, versão incompatível, tipos incorretos, datas inválidas e pontuações fora do intervalo geram uma mensagem clara. Como a validação acontece antes da gravação e a substituição do arquivo é atômica, uma entrada inválida não apaga a base já salva.
