# Validação da Sprint 3

Data da revisão: 19/09/2026.

Todos os testes usaram dados fictícios. O arquivo real do projeto Computational Thinking With Python/dados/dados_alunos.json não foi modificado durante os testes de importação.

## Verificações estáticas

| Verificação | Comando ou método | Resultado |
| --- | --- | --- |
| Sintaxe JavaScript | node --check em 17 arquivos de assets/js | aprovado |
| Módulo do paciente virtual | agent.js executado com estado fictício no Node | respondeu início e intensidade, atribuiu 73 pontos e concluiu a tentativa |
| Sintaxe Python | py_compile em main.py, com cache em /tmp | aprovado |
| Espaços e conflitos de patch | git diff --check | aprovado |
| Marcadores de conflito | busca por <<<<<<<, ======= e >>>>>>> | foi encontrado conflito já gravado no README; corrigido nesta revisão |
| Referências locais | analisador HTML da biblioteca padrão | 18 páginas, 197 href/src válidos, nenhum ID duplicado |
| API removida | busca por fetch, XMLHttpRequest e axios | nenhuma chamada de rede na aplicação |

## Navegador

A interface foi servida localmente como conteúdo estático. Foram exercitados estes cenários:

| Cenário | Resultado |
| --- | --- |
| Login de estudante | direcionou para home_e.html e criou sessão demonstrativa |
| Estudo de Cardiologia | questões respondidas, resultado 3/3 e conclusão registrada |
| Persistência após recarga | atividade continuou disponível no histórico |
| Simulação clínica | sinais vitais visíveis e recolhíveis; anotações disponíveis |
| Paciente virtual | a pergunta “Quando começou a dor e qual é a intensidade?” gerou fala do aluno, resposta da paciente, feedback e mudança de 64 para 73 pontos |
| Salas do professor | criação de sala fictícia mostrou código e estado |
| Painel do administrador | busca de professor e modal funcionaram |
| Teclado | foco do modal e fechamento com Escape verificados |
| Exportação | Salvar dados baixou um pacote real com 18 interações e 1 atividade de estudo |

A simulação é baseada em regras de palavras-chave. Ela não usa API e não é uma IA generativa.

## Responsividade

Foram usados viewports representativos no modo de design responsivo do Safari:

- 360 px
- 390 px
- 768 px
- 1024 px
- 1440 px

A primeira passagem revelou compressão horizontal do conteúdo em 360, 390 e 768 px. A regra do contêiner principal foi corrigida e as cinco larguras foram revalidadas. As capturas finais estão em docs/evidencias.

## Fluxo JSON e Python

O JSON exportado pelo navegador foi copiado para uma pasta temporária junto com main.py.

| Cenário | Resultado |
| --- | --- |
| Primeira importação | 18 interações novas e 1 atividade nova |
| Segunda importação do mesmo arquivo | 0 interações novas e 0 atividades novas |
| Resumo | 18 interações, 1 estudo, 0 simulados e duração total preservada |
| Campos | identificadores, recurso, estado, datas, duração, pontuação e detalhes preservados |
| JSON inválido | erro informado sem sobrescrever a base temporária |
| Comparação após erro | arquivo salvo idêntico ao estado anterior |
| Fixture fictícia com simulado | 1 estudo, 1 simulado, média 73,0 e 317 segundos no resumo |

## Publicação

- GitHub respondeu HTTP 200 em 19/09/2026.
- Vercel respondeu HTTP 200 em 19/09/2026.
- A resposta da Vercel indicou uma versão anterior, modificada em 17/09/2026.
- Nenhum push ou deploy foi executado. Portanto, o código local atual está pronto para revisão, mas não foi verificado em produção.

## Limitações

- O link do Figma não foi encontrado; a fidelidade ao protótipo externo permanece não verificada.
- Não foi executada uma auditoria automatizada WCAG/Lighthouse.
- O console visual do navegador não foi inspecionado com Web Inspector. Os fluxos foram exercitados e as sintaxes foram verificadas separadamente.
- As contas e os resultados são demonstrativos e ficam somente no navegador.
