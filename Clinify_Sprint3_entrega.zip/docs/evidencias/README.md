# Evidências visuais

As imagens foram capturadas durante a execução local em 19/09/2026. As capturas responsivas mostram o controle de largura do modo de design responsivo do Safari.

| Arquivo | Evidência |
| --- | --- |
| estudante-casos-360.jpg | lista de casos após a correção mobile em 360 px |
| estudante-casos-390.jpg | lista de casos em 390 px |
| estudante-casos-768.jpg | lista de casos em 768 px |
| estudante-simulacao-1024.jpg | consulta simulada, sinais vitais e notebook de anotações em 1024 px |
| estudante-casos-1440.jpg | lista de casos em desktop amplo |
| estudante-home-desktop.jpg | início da área do estudante |
| professor-salas-desktop.jpg | salas e acompanhamento do professor |
| administrador-dashboard-desktop.jpg | painel do administrador |

As imagens não comprovam publicação em produção; elas registram a versão executada localmente.
